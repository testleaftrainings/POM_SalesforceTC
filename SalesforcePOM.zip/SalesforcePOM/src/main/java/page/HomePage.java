package page;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class HomePage extends BaseClass {
	
	   
	    private By appLauncherIcon = By.xpath("//div[@class='slds-icon-waffle']");
	    private By viewAllButton = By.xpath("//button[text()='View All']");
	    private By searchBox = By.xpath("//input[@placeholder='Search apps or items...']");

	    public HomePage(ChromeDriver driver) {
	        this.driver = driver;
	    }

	    public HomePage openAppLauncher() throws InterruptedException {
	        driver.findElement(appLauncherIcon).click();
	        Thread.sleep(2000);
	        return this;
	    }

	    public HomePage clickViewAll() {
	        driver.findElement(viewAllButton).click();
	        return this;
	    }

	    public HomePage searchApp(String appName) {
	        driver.findElement(searchBox).sendKeys(appName);
	        return this;
	    }

	    public LeadPage selectApp(String appName) {
	        driver.findElement(By.xpath("//mark[text()='" + appName + "']")).click();
	        return new LeadPage(driver);
	   
	}
}
