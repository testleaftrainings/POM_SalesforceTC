package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.BaseClass;

public class LeadPage extends BaseClass {

	public LeadPage(ChromeDriver driver) {
		this.driver = driver;
	}

	private By newButton = By.xpath("//a[@title='New']");
	private By salutationDropdown = By.xpath("//label[text()='Salutation']//following::button[1]");
	private By salutationOption = By.xpath("//span[text()='Mr.']");
	private By firstName = By.xpath("//label[text()='First Name']/following::input");
	private By lastName = By.xpath("//label[text()='Last Name']/following::input");
	private By companyName = By.xpath("//label[text()='Company']/following::input");
	private By saveButton = By.xpath("//button[@name='SaveEdit']");
	private By toastMessage = By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']");
	private By searchBox = By.xpath("//input[@name='Lead-search-input']");
	private By expandBtn = By.xpath("//span[contains(@class,'slds-icon-utility-down')]");
	private By editOption = By.xpath("//div[text()='Edit']");
	private By deleteOption = By.xpath("//a[@title='Delete']");
	private By confirmDelete = By.xpath("//span[text()='Delete']");

	public LeadPage clickNew() {
		driver.findElement(newButton).click();
		return this;
	}

	public LeadPage enterLeadDetails(String fName, String lName, String company) {
		driver.findElement(salutationDropdown).click();
		driver.findElement(salutationOption).click();
		driver.findElement(firstName).clear();
		driver.findElement(firstName).sendKeys(fName);
		driver.findElement(lastName).clear();
		driver.findElement(lastName).sendKeys(lName);
		driver.findElement(companyName).clear();
		driver.findElement(companyName).sendKeys(company);
		return this;
	}

	public String getToastMessage() {
		return driver.findElement(toastMessage).getText();
	}

	public LeadPage saveLead(String User) {
		driver.findElement(saveButton).click();
		String toastMessage = getToastMessage();
		System.out.println(toastMessage);
		Assert.assertTrue(toastMessage.contains(User), "Verify the Lead Last Name");
		return this;
	}

	public LeadPage searchLead(String name) throws InterruptedException {
		driver.findElement(searchBox).sendKeys(name,Keys.ENTER);
		Thread.sleep(2000);
		return this;
	}

	public LeadPage clickEdit() throws InterruptedException {
		WebElement edit = driver.findElement(editOption);
		driver.executeScript("arguments[0].click()", edit);

		return this;
	}

	public LeadPage clickExpandButton() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(expandBtn).click();
		return this;
	}

	public LeadPage clickDelete() throws InterruptedException {
		Thread.sleep(3000);
		WebElement delete = driver.findElement(deleteOption);
		delete.click();
		driver.findElement(confirmDelete).click();
		String toastMessage = getToastMessage();
		System.out.println(toastMessage);
		Assert.assertTrue(toastMessage.contains("was deleted."), "Verify the Lead Last Name");
		return this;
	}
}
