package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import page.HomePage;

public class DeleteLead extends BaseClass {

	@Test
	public void testCreateLead() throws InterruptedException {
		new HomePage(driver).openAppLauncher()
		.clickViewAll()
		.searchApp("Leads")
		.selectApp("Leads")
	    .searchLead("Michael")
	    .clickExpandButton()
	    .clickDelete();
	}
}
