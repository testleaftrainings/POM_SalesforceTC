package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import page.HomePage;

public class EditLead extends BaseClass {
	
	String lastName = "Qeagle";
	@Test
	public void testCreateLead() throws InterruptedException {
		new HomePage(driver)
		.openAppLauncher()
		.clickViewAll()
		.searchApp("Leads")
		.selectApp("Leads")
		.searchLead("Michael")
		.clickExpandButton()
        .clickEdit()
        .enterLeadDetails("Ajay", lastName, "Qeagle")
        .saveLead(lastName);

		
	}
}
