package vanilla_script;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class CreateLead {

	public static void main(String[] args) throws InterruptedException {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		driver.get("https://login.salesforce.com/");
		driver.findElement(By.id("username")).sendKeys("majay3574@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Ajaymichael@123");
		driver.findElement(By.id("Login")).click();

		Thread.sleep(8000);
		WebElement appLauncher = driver.findElement(By.xpath("//div[@class='slds-icon-waffle']"));
		driver.executeScript("arguments[0].click()", appLauncher);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		String appName="Leads";
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys(appName);
		// Navigate to Leads
		driver.findElement(By.xpath("//mark[text()='" + appName + "']")).click();
		driver.findElement(By.xpath("//a[@title='New']")).click();

		// Enter Lead details
		String leadFirstName = "Ajay";
		String leadLastName = "Michael";
		String leadCompany = "Tesleaf";

		driver.findElement(By.xpath("//label[text()='Salutation']//following::button[1]")).click();
		driver.findElement(By.xpath("//span[text()='Mr.']")).click();
		driver.findElement(By.xpath("//label[text()='First Name']/following::input")).sendKeys(leadFirstName);
		driver.findElement(By.xpath("//label[text()='Last Name']/following::input")).sendKeys(leadLastName);
		driver.findElement(By.xpath("//label[text()='Company']/following::input")).sendKeys(leadCompany);

		// Save the new Lead
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();

		// Verify the Lead creation
		String toastMessage = driver
				.findElement(By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']"))
				.getText();
		System.out.println(toastMessage);
		Assert.assertTrue(toastMessage.contains(leadLastName), "Verify the Lead Last Name");

		
		driver.quit();

	}

}
