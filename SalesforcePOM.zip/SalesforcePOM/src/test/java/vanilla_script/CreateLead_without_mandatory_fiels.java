package vanilla_script;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public class CreateLead_without_mandatory_fiels {
	public static void main(String[] args) throws InterruptedException {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

		// Login to Salesforce
		driver.get("https://login.salesforce.com/");
		driver.findElement(By.id("username")).sendKeys("majay3574@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Ajaymichael@123");
		driver.findElement(By.id("Login")).click();

		Thread.sleep(8000);
		WebElement appLauncher = driver.findElement(By.xpath("//div[@class='slds-icon-waffle']"));
		driver.executeScript("arguments[0].click()", appLauncher);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		String appName="Leads";
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys(appName);
		// Navigate to Leads
		driver.findElement(By.xpath("//mark[text()='" + appName + "']")).click();
		driver.findElement(By.xpath("//a[@title='New']")).click();
		
		String leadFirstName = "Ajay";
		

		driver.findElement(By.xpath("//label[text()='Salutation']//following::button[1]")).click();
		driver.findElement(By.xpath("//span[text()='Mr.']")).click();
		driver.findElement(By.xpath("//label[text()='First Name']/following::input")).sendKeys(leadFirstName);
		
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		
		String errorText=driver.findElement(By.xpath("//h2[text()='We hit a snag.']")).getText();
		System.out.println(errorText);
		Assert.assertTrue(errorText.contains("We hit a snag."), "Verify that the lead was not created due to an unfilled mandatory field");
		driver.close();

	}
}
