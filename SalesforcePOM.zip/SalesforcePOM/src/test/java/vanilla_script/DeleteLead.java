package vanilla_script;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class DeleteLead {

	public static void main(String[] args) throws InterruptedException {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

		// Login to Salesforce
		driver.get("https://login.salesforce.com/");
		driver.findElement(By.id("username")).sendKeys("majay3574@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Ajaymichael@123");
		driver.findElement(By.id("Login")).click();

		Thread.sleep(8000);
		WebElement appLauncher = driver.findElement(By.xpath("//div[@class='slds-icon-waffle']"));
		driver.executeScript("arguments[0].click()", appLauncher);

		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		String appName = "Leads";
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys(appName);
		// Navigate to Leads
		driver.findElement(By.xpath("//mark[text()='" + appName + "']")).click();
		String leadLastName = "Michael";
		WebElement searchBox = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='Lead-search-input']")));
		searchBox.sendKeys(leadLastName);
		searchBox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		WebElement expandIcon =driver.findElement(By.xpath("//span[contains(@class,'slds-icon-utility-down')]"));
		driver.executeScript("arguments[0].click()", expandIcon);

		// Delete the Lead
		WebElement deleteButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Delete']")));
		deleteButton.click();

		WebElement confirmDeleteButton = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Delete']")));
		confirmDeleteButton.click();

		// Verify the Lead deletion
		WebElement noItemsMessage = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='No items to display.']")));
		Assert.assertTrue(noItemsMessage.isDisplayed(), "Verify the Lead has been deleted");

		// Close the browser
		driver.quit();

	}

}
