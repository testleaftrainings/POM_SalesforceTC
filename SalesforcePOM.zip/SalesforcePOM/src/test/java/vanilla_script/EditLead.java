package vanilla_script;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class EditLead {
	public static void main(String[] args) throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get("https://login.salesforce.com/");
		driver.findElement(By.id("username")).sendKeys("majay3574@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Ajaymichael@123");
		driver.findElement(By.id("Login")).click();

		Thread.sleep(8000);
		WebElement appLauncher = driver.findElement(By.xpath("//div[@class='slds-icon-waffle']"));
		driver.executeScript("arguments[0].click()", appLauncher);

		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		String appName = "Leads";
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys(appName);
		
		driver.findElement(By.xpath("//mark[text()='" + appName + "']")).click();
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys("Michael" + Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[contains(@class,'slds-icon-utility-down')]")).click();

		WebElement edit = driver.findElement(By.xpath("//div[text()='Edit']"));
		driver.executeScript("arguments[0].click()", edit);
		WebElement firstName = driver.findElement(By.xpath("//input[@name='firstName']"));
		firstName.clear();
		firstName.sendKeys("Muthu");
		WebElement companyName = driver.findElement(By.xpath("//input[@name='Company']"));
		companyName.clear();
		companyName.sendKeys("Qeagle");
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		String text = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
		System.out.println(text);
		if (text.contains("Muthu")) {
			System.out.println("The Lead Updated Successfully ");
		}
		driver.close();
	}
}
